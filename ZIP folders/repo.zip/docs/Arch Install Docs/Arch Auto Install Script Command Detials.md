# Arch Auto Install Script Command Details

*This Markdown file goes into detail about the script that installs the browser on arch*

## 1)It calls "#!bin/bash" Or the bash shell
## 2)it previews the lisense
## 3)promts the user to agree with the lisense and saves the answer to a value
## 4)checks if the value is y to continue and it does:
## 4.1)Updates the system with pacman
## 4.2)installs git
## 4.3)It installs python
## 4.4)It installs python3
## 4.5)It installs python pip
## 4.6)It installs python3 pip
## 4.7)Clones the repo in a folder called install
## 4.8)It Installs PyQt5 the library that powers the frontend of the browser
## 4.9)It installs sip for the backend of the browser
## 4.10)It installs requests for the some extra backend of the browser
## 4.11)It Installs PyQtWebEngine to power all the backend and some of the frontend of the browser
## 4.12)It prints that the install finished with no errors
## 5)If the user denied the lisence it does this:
## 5.1)It prints that the install was unsucessful due to the user dening the lisence
## 6)And ends with fi to end the If function
