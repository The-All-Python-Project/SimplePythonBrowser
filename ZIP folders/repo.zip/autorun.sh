#!/bin/bash
# If you want it to cd in the directory for easy acess to the program uncomment the next line below
# cd YOURFILEPATHTOTHEDIRECTORIYOUINSTALLED
python Simple_browser.py
python3 Simple_browser.py
