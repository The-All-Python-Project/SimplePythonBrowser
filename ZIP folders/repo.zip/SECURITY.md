# Security Policy

## Supported Versions

| Version         | Supported          | Windows
| -------         | ------------------ | ----------------------
| v.alpha 1.0     | :x:                | :x:
| v.alpha 1.1     | :x:                | :x:
| v.alpha 1.2     | ✅                 | ✅
| v.alpha 1.3     | :white_check_mark: | ✅
## Reporting a Vulnerability


Some Antiviruses may detect it as a virus because the code is not signed and we cant sign it at the moment 
How to make an exeception wikis 

*Avast:https://support.avast.com/en-ww/article/Antivirus-scan-exclusions
*AVG:https://support.avg.com/SupportArticleView?l=en&urlname=AVG-Antivirus-scan-exclusions
*McAfee:https://knowledge.civilgeo.com/knowledge-base/adding-an-exception-to-mcafee-firewall/
