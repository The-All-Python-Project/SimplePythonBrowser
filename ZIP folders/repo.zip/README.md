# SimplePythonBrowser
A simple browser using PyQt5


Website: http://pythonbrowser.ml

![index](https://user-images.githubusercontent.com/85512286/142732638-7172368f-72c2-45b8-b7b8-e36f646c8a7b.jpg)

DISCORD SERVER:https://discord.gg/KKESvV24Ws

**For Linux PCs more on docs folder** 

WARNING:Some antivirus may detect this as an virus this is because the code is not signed (More on SECURTY.md Exeception wikis for antiviruses also on SECURITY.md)  

This is really beta. The installation is fairly easy, and the code is open source. This is simply for fun; I don't want to compete with other browsers.





## Supported Versions

| Version         | Supported          | Windows               | Linux               |
| -------         | ------------------ | ----------------------| --------------------|
| v1.0    | :x: | :x:                                  | :x:                 |
| v1.1     |:x:  |:x:                                   | :x:                 |
| v1.2     |:white_check_mark: | :white_check_mark:     | ✅                   |
| v.1.3   | ✅  |  ✅   | ✅


# installer compatability

| Windows Version   |  Supported            
| ----------------  | ------------------                      
|   95,98,2000      |    :x:  
|      XP           |    :x:
|  Vista, Windows 7 |    ✅
|     Windows 8     |    ✅
|    Windows 10     |   :white_check_mark:



