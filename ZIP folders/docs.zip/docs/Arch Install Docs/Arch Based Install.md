## Arch Based Install
**arch based distros are like arch itself or manjaro everything that has pacman as the packege manager**

## 1) make a directory to install it and open a terminal and type "git clone https://github.com/Python-Browser/SimplePythonBrowser > install" and cd to it with "cd install"
## 2) in the directory type "chmod +x autoinstallarch.sh" and run it with "sudo sh autoinstallarch.sh" it will go through and install everything that needs to

**Optional: you can edit in the install directory autorun.sh and unhastag the second line to cd to the dirctory you just installed on!!**