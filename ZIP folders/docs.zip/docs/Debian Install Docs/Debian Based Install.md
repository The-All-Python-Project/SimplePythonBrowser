# Debain Based install
**Debian based distros are like ubuntu or linux mint linux lite etc or if your distro has apt as the packege manager is debian based**

## 1)First you have to make a dircetory to install the browser and in that dirctory open a terminal and type "git clone https://github.com/Python-Browser/SimplePythonBrowser > install" to clone the repository
## 2)Second you cd to the directory that it created with "cd install" and type "chmod +x autoinstallded.sh" and type "sudo sh autoinstallded.sh" to run it it will go through and install everything you need

**Optional: you can edit in the install directory autorun.sh and unhastag the second line to cd to the dirctory you just installed on!!**